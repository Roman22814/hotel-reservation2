# Hotel Room Reservation System

## Features
- Make a hotel room reservation
- Simulate payment
- View confirmation
- Cancel reservation

## Run Locally
```bash
pip install -r requirements.txt
python app.py
```